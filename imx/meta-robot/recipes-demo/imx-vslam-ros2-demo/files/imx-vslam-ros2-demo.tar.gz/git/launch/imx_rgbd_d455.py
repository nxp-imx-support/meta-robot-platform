# vSLAM ros2 application
import os
from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    path_to_vocabulary = os.path.join(
      get_package_share_directory('imx_vslam_ros2_demo'),
      'param',
      'orbvoc.dbow3'
    )
    path_to_settings = os.path.join(
      get_package_share_directory('imx_vslam_ros2_demo'),
      'param',
      'RealSense_D455.yaml'
    )
    # include another launch file
    launch_include = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('imx_vslam_ros2_demo'),
                'launch',
                'rs_vslam_launch.py'))
    )
    imx_rgbd_d455_node = Node(
            package='imx_vslam_ros2_demo',
            executable='imx_rgbd_d455',
            name='imx_rgbd_d455',
            output='screen',
            arguments=[path_to_vocabulary, path_to_settings]
        ) 
    return LaunchDescription([
        launch_include,
        imx_rgbd_d455_node,
	])