# vSLAM ros2 application and ros2 bag play <path>/MH_01_easy.db3 before
import os
from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    path_to_vocabulary = os.path.join(
      get_package_share_directory('imx_vslam_ros2_demo'),
      'param',
      'orbvoc.dbow3'
    )
    path_to_settings = os.path.join(
      get_package_share_directory('imx_vslam_ros2_demo'),
      'param',
      'EuRoC.yaml'
    )
    return LaunchDescription([
        Node(
            package='imx_vslam_ros2_demo',
            executable='imx_stereo_camera',
            name='imx_stereo_camera',
            output='screen',
            arguments=[path_to_vocabulary, path_to_settings]
        )
	])