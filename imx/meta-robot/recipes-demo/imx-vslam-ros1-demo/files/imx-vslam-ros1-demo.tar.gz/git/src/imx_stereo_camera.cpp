/**
* This file is part of imx-hc-slam
*
* Copyright (C) 2017-2023 NXP
* Copyright (C) 2017-2021 Carlos Campos, Richard Elvira, Juan J. Gómez Rodríguez, José M.M. Montiel and Juan D. Tardós, University of Zaragoza.
* Copyright (C) 2014-2016 Raúl Mur-Artal, José M.M. Montiel and Juan D. Tardós, University of Zaragoza.
*
* imx-hc-slam is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
* License as published by the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* imx-hc-slam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even
* the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with imx-hc-slam.
* If not, see <http://www.gnu.org/licenses/>.
*/


#include <iostream>
#include <algorithm>
#include <fstream>
#include <chrono>
#include <condition_variable>

#include <ros/ros.h>
#include <cv_bridge/cv_bridge.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <sensor_msgs/PointCloud2.h>
#include <Eigen/Core>
#include <opencv2/core/core.hpp>
#include <opencv2/core/eigen.hpp>
#include <tf2_ros/transform_broadcaster.h>
#include <tf2/LinearMath/Transform.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseArray.h>

#include <opencv2/core/core.hpp>

#include <System.h>

using namespace std;

class ImageGrabber
{
public:
    ImageGrabber(imx_hc_slam::System *pSLAM):mpSLAM(pSLAM){}

    void GrabStereo(const sensor_msgs::ImageConstPtr& msgLeft, const sensor_msgs::ImageConstPtr& msgRight);

    void PubPose();
    void PubImage();
    void PubPointCloud();

    imx_hc_slam::System* mpSLAM;
    nav_msgs::Path path_;
    float imageScale;
    ros::NodeHandle *pNodeHandle;
    ros::Publisher path_pub;
    ros::Publisher pcl_pub;
    ros::Publisher frame_pub;
private:
    sensor_msgs::PointCloud2 MapPointsToPointCloud (
            std::vector<imx_hc_slam::MapPoint*> map_points);
    tf2::Transform TransformFromMat (cv::Mat position_mat);

    std::queue<Sophus::SE3f> pose_buffer_;
    std::mutex pose_mutex_;
    std::condition_variable pose_cv_;

    std::queue<bool> image_buffer_;
    std::mutex image_mutex_;
    std::condition_variable image_cv_;

    std::queue<std::vector<imx_hc_slam::MapPoint*>> point_buffer_;
    std::mutex point_mutex_;
    std::condition_variable point_cv_;
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "IMXSTEREO_CAMERA");
    ros::start();

    if(argc != 3)
    {
        cerr << endl << "Usage: rosrun imx_vslam_ros1_demo imx_stereo_camera path_to_vocabulary path_to_settings" << endl;        
        ros::shutdown();
        return 1;
    }

    // Create SLAM system. It initializes all system threads and gets ready to process frames.
    imx_hc_slam::System SLAM(argv[1], argv[2], imx_hc_slam::System::STEREO, false);

    ImageGrabber igb(&SLAM);

    ros::NodeHandle nh;
    igb.pNodeHandle = &nh;
    igb.imageScale = SLAM.GetImageScale();

    igb.path_pub = nh.advertise<nav_msgs::Path>("/camera_path", 10);
    igb.pcl_pub = nh.advertise<sensor_msgs::PointCloud2>("/map_pointcloud2", 10);
    igb.frame_pub = nh.advertise<sensor_msgs::Image>("/keypoint_frame", 10);
    
    message_filters::Subscriber<sensor_msgs::Image> left_sub(nh, "/cam0/image_raw", 100);
    message_filters::Subscriber<sensor_msgs::Image> right_sub(nh, "/cam1/image_raw", 100);
    typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::Image> sync_pol;
    message_filters::Synchronizer<sync_pol> sync(sync_pol(10), left_sub, right_sub);
    sync.registerCallback(boost::bind(&ImageGrabber::GrabStereo, &igb, _1, _2));

    std::thread pub_image_thread(&ImageGrabber::PubImage, &igb);
    std::thread pub_pose_thread(&ImageGrabber::PubPose, &igb);
    std::thread pub_pcl_thread(&ImageGrabber::PubPointCloud, &igb);

    ros::spin();

    // Stop all threads
    SLAM.Shutdown();
  
    ros::shutdown();

    return 0;
}

sensor_msgs::PointCloud2 ImageGrabber::MapPointsToPointCloud(
        std::vector<imx_hc_slam::MapPoint*> map_points)
{

    sensor_msgs::PointCloud2 cloud;

    const int num_channels = 3; // x y z

    cloud.header.stamp = ros::Time::now();
    cloud.header.frame_id = "map";
    cloud.height = 1;
    cloud.width = map_points.size();
    cloud.is_bigendian = false;
    cloud.is_dense = true;
    cloud.point_step = num_channels * sizeof(float);
    cloud.row_step = cloud.point_step * cloud.width;
    cloud.fields.resize(num_channels);

    std::string channel_id[] = { "x", "y", "z"};
    for (int i = 0; i < num_channels; i++) {
        cloud.fields[i].name = channel_id[i];
        cloud.fields[i].offset = i * sizeof(float);
        cloud.fields[i].count = 1;
        cloud.fields[i].datatype = sensor_msgs::PointField::FLOAT32;
    }

    cloud.data.resize(cloud.row_step * cloud.height);

    unsigned char *cloud_data_ptr = &(cloud.data[0]);

    float data_array[num_channels];
    for (unsigned int i = 0; i < cloud.width; i++) {
        if (map_points.at(i)->nObs >= 2) {

            data_array[0] = (float)map_points.at(i)->GetWorldPos()(2);
            data_array[1] = (float)(-1.0 * map_points.at(i)->GetWorldPos()(0));
            data_array[2] = (float)(-1.0 * map_points.at(i)->GetWorldPos()(1));

            memcpy(cloud_data_ptr + (i * cloud.point_step),
                   data_array, num_channels * sizeof(float));
        }
    }
    return cloud;
}

tf2::Transform ImageGrabber::TransformFromMat (cv::Mat position_mat)
{
    cv::Mat rotation(3, 3, CV_32F);
    cv::Mat translation(3, 1, CV_32F);

    rotation = position_mat.rowRange(0, 3).colRange(0, 3);
    translation = position_mat.rowRange(0, 3).col(3);


    tf2::Matrix3x3 tf_camera_rotation (rotation.at<float> (0, 0),
                                       rotation.at<float> (0, 1),
                                       rotation.at<float> (0, 2),
                                       rotation.at<float> (1, 0),
                                       rotation.at<float> (1, 1),
                                       rotation.at<float> (1, 2),
                                       rotation.at<float> (2, 0),
                                       rotation.at<float> (2, 1),
                                       rotation.at<float> (2, 2));

    tf2::Vector3 tf_camera_translation (translation.at<float> (0),
                                        translation.at<float> (1),
                                        translation.at<float> (2));

    //Coordinate transformation matrix from orb coordinate system to ros coordinate system
    const tf2::Matrix3x3 tf_orb_to_ros (0, 0, 1,
                                       -1, 0, 0,
                                        0, -1, 0);

    //Transform from orb coordinate system to ros coordinate system on camera coordinates
    tf_camera_rotation = tf_orb_to_ros * tf_camera_rotation;
    tf_camera_translation = tf_orb_to_ros * tf_camera_translation;

    //Inverse matrix
    tf_camera_rotation = tf_camera_rotation.transpose();
    tf_camera_translation = -(tf_camera_rotation * tf_camera_translation);

    //Transform from orb coordinate system to ros coordinate system on map coordinates
    tf_camera_rotation = tf_orb_to_ros * tf_camera_rotation;
    tf_camera_translation = tf_orb_to_ros * tf_camera_translation;

    return tf2::Transform (tf_camera_rotation, tf_camera_translation);
}
void ImageGrabber::GrabStereo(const sensor_msgs::ImageConstPtr& msgLeft, const sensor_msgs::ImageConstPtr& msgRight)
{
    // Copy the ros image message to cv::Mat.
    cv_bridge::CvImageConstPtr cv_ptrLeft;
    try
    {
        cv_ptrLeft = cv_bridge::toCvShare(msgLeft);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }

    cv_bridge::CvImageConstPtr cv_ptrRight;
    try
    {
        cv_ptrRight = cv_bridge::toCvShare(msgRight);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }
    if(imageScale != 1.f)
    {
        int width = cv_ptrLeft->image.cols * imageScale;
        int height = cv_ptrLeft->image.rows * imageScale;
        cv::resize(cv_ptrLeft->image, cv_ptrLeft->image, cv::Size(width, height));
        cv::resize(cv_ptrRight->image, cv_ptrRight->image, cv::Size(width, height));
    }
   
    Sophus::SE3f Tcw_SE3F = mpSLAM->TrackStereo(cv_ptrLeft->image, cv_ptrRight->image, cv_ptrLeft->header.stamp.toSec(), imx_hc_slam::Settings::COMPUTE_TYPE_NEON);

    std::unique_lock<std::mutex> locker_pose(pose_mutex_);
    pose_buffer_.push(Tcw_SE3F);
    locker_pose.unlock();
    pose_cv_.notify_one();

    std::unique_lock<std::mutex> locker_image(image_mutex_);
    image_buffer_.push(true);
    locker_image.unlock();
    image_cv_.notify_one();

    std::unique_lock<std::mutex> locker_point(point_mutex_);
    point_buffer_.push(mpSLAM->GetAllMapPoints());
    locker_point.unlock();
    point_cv_.notify_one();
    
}

void ImageGrabber::PubPose()
{
    Eigen::Matrix4f Tcw_Matrix;
    cv::Mat Tcw;
    geometry_msgs::TransformStamped tf_msg;
    geometry_msgs::PoseStamped pose_msg;

    tf2_ros::TransformBroadcaster tf_broadcaster;

    while (ros::ok()){
        std::unique_lock<std::mutex> locker_pose(pose_mutex_);
        while(pose_buffer_.empty())
            pose_cv_.wait(locker_pose);
        Tcw_Matrix = pose_buffer_.front().matrix();
        pose_buffer_.pop();
        locker_pose.unlock();

        cv::eigen2cv(Tcw_Matrix, Tcw);
        tf2::Transform tf_transform = TransformFromMat(Tcw);

        tf_msg.header.frame_id = "map";
        tf_msg.child_frame_id = "camera_link";
        tf_msg.header.stamp = ros::Time::now();
        tf_msg.transform = tf2::toMsg(tf_transform);

        tf_broadcaster.sendTransform(tf_msg);

        pose_msg.pose.position.x = tf_transform.getOrigin().getX();
        pose_msg.pose.position.y = tf_transform.getOrigin().getY();
        pose_msg.pose.position.z = tf_transform.getOrigin().getZ();

        pose_msg.pose.orientation.x = tf_transform.getRotation().getX();
        pose_msg.pose.orientation.y = tf_transform.getRotation().getY();
        pose_msg.pose.orientation.z = tf_transform.getRotation().getZ();
        pose_msg.pose.orientation.w = tf_transform.getRotation().getW();

        path_.header = tf_msg.header;
        path_.poses.push_back(pose_msg);
        path_pub.publish(path_);
    }
}

void ImageGrabber::PubImage()
{
    sensor_msgs::Image img_msg;
    cv_bridge::CvImage img_bridge;
    cv::Mat toshow;
    std_msgs::Header header;
    bool received_image;
    header.frame_id = "camera_link";
    while (ros::ok()) {

        std::unique_lock<std::mutex> locker_image(image_mutex_);
        while (image_buffer_.empty())
            image_cv_.wait(locker_image);
        received_image = image_buffer_.front();
        image_buffer_.pop();
        locker_image.unlock();

        if(received_image) {
            toshow = mpSLAM->GetFrameDrawer()->DrawFrame(1.0f);
            header.stamp = ros::Time::now();
            img_bridge = cv_bridge::CvImage(header, "bgr8", toshow);
            img_bridge.toImageMsg(img_msg);
            frame_pub.publish(img_msg);
        }
    }
}

void ImageGrabber::PubPointCloud()
{
    std::vector<imx_hc_slam::MapPoint *> orb_point;
    while (ros::ok()) {
        std::unique_lock<std::mutex> locker_point(point_mutex_);
        while (point_buffer_.empty())
            point_cv_.wait(locker_point);
        orb_point = point_buffer_.front();
        point_buffer_.pop();
        locker_point.unlock();

        sensor_msgs::PointCloud2 cloud = MapPointsToPointCloud(orb_point);
        pcl_pub.publish(cloud);
    }
}

