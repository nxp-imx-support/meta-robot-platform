#ifndef _CONFIG_H_
#define _CONFIG_H_

/**
 * @brief Motor and servo test mode.
 * 
 * Update motor and servo PWM pulse width every 100ms. Use debugger
 * to change value @ref MotorTestFakePacket and @ref steer_offset.
 * Do NOT change @ref steer, @ref pan and @ref tlt, as in this
 * case they are updated automatically.
 */
#define CONFIG_SERVO_TEST (0U)

/**
 * @brief Encoders test mode.
 * 
 * Print encoders raw value every 100ms. Connect to LPUART1 to 
 * monitor these value. 
 * @warning: Make sure DISABLE @ref CONFIG_MOTOR_SPEED_CL before
 * encoder test complete.
 */
#define CONFIG_ENCOD_TEST (0U)

/**
 * @brief Motor speed closed-loop control enable.
 * 
 * Enable motor speed closed-loop control. Adjust @ref motorL_pid
 * and @ref motorR_pid to reach optimal control accuracy.
 * @warning Make sure encoders are confirmed working, and both 
 * motor spin direction and encoders direction is correct.
 */
#define CONFIG_MOTOR_SPEED_CL (1U)

/**
 * @brief Motor differential speed calibration.
 * 
 * Enable motor differential speed calibration process. This must be
 * done before @ref CONFIG_SPDDIF_ENABLE is set to 1. During this
 * process, @ref CONFIG_SERVO_TEST can NOT be set.
 */
#define CONFIG_SPDDIF_CALIBRATION (0U)

/**
 * @brief Motor differential speed control enable.
 * 
 * Enable motor differential speed control. TODO: WIP.
 */
#define CONFIG_SPDDIF_ENABLE (1U)

/**
 * @brief Communication test mode.
 * 
 * Print received packet infomation upon packet arrives. If speed
 * readback is required, print infomation of the sent packet too.
 * Received data would NOT take effect if enabled. Disable this 
 * option to apply received data to actual car control.
 */
#define CONFIG_COMM_TEST (0U)

/**
 * @brief Odometry report function
 * 
 * TODO: Add detail description.
 */
#define CONFIG_ODOMETRY_REPORT (1U)

#endif // ! _CONFIG_H_