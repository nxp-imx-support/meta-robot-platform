#ifndef _COMM_H_
#define _COMM_H_

#include <stdint.h>
#include <sys_rmcall.h>
#include "config.h"

typedef enum _comm_controlFlag
{
    comm_controlFlag_telemReq = (0b01U << 0U), ///< Request telemetry data from MCU.
    comm_controlFlag_odomEnable = (0b10U << 2U), ///< Enable odometry auto-report from MCU.
    comm_controlFlag_odomDisable = (0b01U << 2U), ///< Disable odometry auto-report from MCU.
    comm_controlFlag_odomCheck = (0b11U << 2U), ///< Check odometry command. Not used as a flag!.
}comm_controlFlag_t;

typedef struct _comm_packet_control
{
    int16_t motor_speed;    ///< Motor speed. Speed below 128 means reverse speed.
    int16_t servo_steer;    ///< Forward steering servo.
    int16_t cam_pan;        ///< Camera yaw angle.
    int16_t cam_tlt;        ///< Camera pitch angle.
    uint32_t controlFlag;   ///< Or-ed bits of @ref comm_controlFlag_t.
}comm_packet_control_t;

typedef struct _comm_packet_setPID
{
    float motor_l_p, motor_l_i, motor_l_d, motor_l_ilim;
    float motor_r_p, motor_r_i, motor_r_d, motor_r_ilim;
}comm_packet_setPID_t;

typedef struct _comm_packet_telemetry
{
    int16_t motor_speed_l;
    int16_t motor_speed_r;
}comm_packet_telemetry_t;


#if defined(CONFIG_ODOMETRY_REPORT) && (CONFIG_ODOMETRY_REPORT != 0U)
typedef struct _comm_packet_odometry
{
    float velocity;
    float rotation;
}comm_packet_odometry_t;
#endif // ! CONFIG_ODOMETRY_REPORT

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 
 * 
 * @param _recvData 
 * @param _recvSize 
 * @param _userData 
 */
void COMM_PacketReceive_Telemetry(void *_recvData, uint16_t _recvSize, void *_userData);

/**
 * @brief 
 * 
 * @param _recvData 
 * @param _recvSize 
 * @param _userData 
 */
void COMM_PacketReceive_Odometry(void *_recvData, uint16_t _recvSize, void *_userData);

#ifdef __cplusplus
}
#endif

#endif // _COMM_H_