#include "cmodule_common.h"

#ifdef __cplusplus
extern "C"{
#endif

void HAL_EnterCritical(void)
{

}

void HAL_ExitCritical(void)
{

}

#ifdef __cplusplus
}
#endif