#include "comm.h"

#ifdef __cplusplus
extern "C" {
#endif

void COMM_PacketReceive_Telemetry(void *_recvData, uint16_t _recvSize, void *_userData)
{
    assert(sizeof(comm_packet_telemetry_t) == _recvSize);
    comm_packet_telemetry_t *ptr = (comm_packet_telemetry_t*)_recvData;
    printf("TELE: Motor Speed\nL: %4.4hd R: %4.4hd\n", ptr->motor_speed_l, ptr->motor_speed_r);
}

rmcall_handle_t comm_packetReceive_telemetry =
{
    .handleId = 0x0201U,
    .handler = COMM_PacketReceive_Telemetry,
    .userData = NULL,
};

#if defined(CONFIG_ODOMETRY_REPORT) && (CONFIG_ODOMETRY_REPORT != 0U)
pthread_mutex_t odom_mutex;
pthread_cond_t odom_cond;
comm_packet_odometry_t odom_data;
volatile bool odom_ready = false;

void COMM_PacketReceive_Odometry(void *_recvData, uint16_t _recvSize, void *_userData)
{
    assert(sizeof(comm_packet_odometry_t) == _recvSize);
    comm_packet_odometry_t *ptr = (comm_packet_odometry_t*)_recvData;
    //printf("ODOM: Speed & Rotation\nL: %4.4f R: %4.4f\n", ptr->velocity, ptr->rotation);
    if(0 == pthread_mutex_lock(&odom_mutex))
    {
        memcpy((void*)&odom_data, _recvData, sizeof(comm_packet_odometry_t));
        odom_ready = true;
        pthread_cond_signal(&odom_cond);
        pthread_mutex_unlock(&odom_mutex);
    }
}

rmcall_handle_t comm_packetReceive_odometry =
{
    .handleId = 0x0202U,
    .handler = COMM_PacketReceive_Odometry,
    .userData = NULL,
};
#endif // ! CONFIG_ODOMETRY_REPORT

#ifdef __cplusplus
}
#endif
