/**
* This file is part of imx-hc-slam
*
* Copyright (C) 2017-2022 NXP
* Copyright (C) 2017-2021 Carlos Campos, Richard Elvira, Juan J. Gómez Rodríguez, José M.M. Montiel and Juan D. Tardós, University of Zaragoza.
* Copyright (C) 2014-2016 Raúl Mur-Artal, José M.M. Montiel and Juan D. Tardós, University of Zaragoza.
*
* imx-hc-slam is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
* License as published by the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* imx-hc-slam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even
* the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with imx-hc-slam.
* If not, see <http://www.gnu.org/licenses/>.
*/


#include <iostream>
#include <algorithm>
#include <vector>
#include <fstream>
#include <chrono>
#include <condition_variable>

#include <ros/ros.h>
#include <cv_bridge/cv_bridge.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <sensor_msgs/PointCloud2.h>
#include <Eigen/Core>
#include <opencv2/core/core.hpp>
#include <opencv2/core/eigen.hpp>
#include <tf2_ros/transform_broadcaster.h>
#include <tf2/LinearMath/Transform.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseArray.h>

#include <pcl/common/transforms.h>
#include <pcl/common/projection_matrix.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/voxel_grid.h>
#ifdef WITH_INERTIAL
#include <sensor_msgs/Imu.h>
#include <std_msgs/Float32.h>
#endif
#include <octomap/octomap.h> 
#include <opencv2/core/core.hpp>

#include <System.h>

using namespace std;
using namespace Eigen;
#ifdef ENABLE_ODOMETRY
struct odometry_data
{
    Sophus::SE3f Tcw_SE3F;
    Eigen::Vector3f linear_velocity;
    Eigen::Vector3f angular_velocity;
};
#endif
class ImageGrabber
{
public:
    ImageGrabber(imx_hc_slam::System *pSLAM):mpSLAM(pSLAM){}
    imx_hc_slam::System* mpSLAM;
    void GrabRGBD(const sensor_msgs::ImageConstPtr& msgRGB, const sensor_msgs::ImageConstPtr& msgD);
#ifdef WITH_INERTIAL
    void GrabIMU(const sensor_msgs::Imu& msgIMU);
    std::mutex mMutexImu;
    std::vector<imx_hc_slam::IMU::Point*> pImuMeas;
    std::vector<imx_hc_slam::IMU::Point> vImuMeas;
#endif
#ifdef ENABLE_ODOMETRY
    ros::Publisher odom_pub;
    void PubOdometry();
    std::queue<odometry_data> odom_buffer_;
    std::mutex odom_mutex_;
    std::condition_variable odom_cv_;
#endif
    void PubImage();
    float imageScale;
    ros::NodeHandle *pNodeHandle;
    ros::Publisher pcl_pub;
#ifdef ENABLE_IMAGE_RENDER
    ros::Publisher frame_pub;
#endif
   
protected:
    tf2::Transform TransformFromMat (cv::Mat position_mat);
#ifdef ENABLE_IMAGE_RENDER    
    std::queue<bool> image_buffer_;
    std::mutex image_mutex_;
    std::condition_variable image_cv_;
#endif
    sensor_msgs::PointCloud2 output;
};
PointCloud::Ptr globalMap(new PointCloud);
int main(int argc, char **argv)
{
    ros::init(argc, argv, "IMXAIBOT1_VSLAM");
    ros::start();

    if(argc != 3)
    {
        cerr << endl << "Usage: rosrun imx-aibot1_vslam imx-aibot1_vslam path_to_vocabulary path_to_settings" << endl;        
        ros::shutdown();
        return 1;
    }

    // Create SLAM system. It initializes all system threads and gets ready to process frames.
#ifdef WITH_INERTIAL
    imx_hc_slam::System SLAM(argv[1], argv[2], imx_hc_slam::System::IMU_RGBD, false);
#else
    imx_hc_slam::System SLAM(argv[1], argv[2], imx_hc_slam::System::RGBD, false);
#endif
    ImageGrabber igb(&SLAM);

    ros::NodeHandle nh;
    igb.pNodeHandle = &nh;
    igb.imageScale = SLAM.GetImageScale();

    igb.pcl_pub = nh.advertise<sensor_msgs::PointCloud2>("/imx_hc_slam_cloud", 10);
#ifdef ENABLE_IMAGE_RENDER
    igb.frame_pub = nh.advertise<sensor_msgs::Image>("/keypoint_frame", 10);
#endif

#ifdef ENABLE_ODOMETRY
    igb.odom_pub = nh.advertise<nav_msgs::Odometry>("/imx_aibot1_odometer/odometry", 10);
#endif
    
    message_filters::Subscriber<sensor_msgs::Image> rgb_sub(nh, "/camera/color/image_raw", 10); //Intel® RealSense™ D455's topic
    message_filters::Subscriber<sensor_msgs::Image> depth_sub(nh, "/camera/depth/image_rect_raw", 10); //Intel® RealSense™ D455's topic
    typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::Image> sync_pol;
    message_filters::Synchronizer<sync_pol> sync(sync_pol(10), rgb_sub, depth_sub);
    sync.registerCallback(boost::bind(&ImageGrabber::GrabRGBD, &igb, _1, _2));
#ifdef WITH_INERTIAL
    ros::Subscriber imu_sub = nh.subscribe("/camera/imu", 150, &ImageGrabber::GrabIMU, &igb);
#endif

#ifdef ENABLE_ODOMETRY
    std::thread pub_odom_thread(&ImageGrabber::PubOdometry, &igb);
#endif

#ifdef ENABLE_IMAGE_RENDER
    std::thread pub_image_thread(&ImageGrabber::PubImage, &igb);
#endif

    ros::spin();

    // Stop all threads
    SLAM.Shutdown();

    globalMap->is_dense = false;
    cout << "point cloud has " << globalMap->size() << " points." << endl;

    // voxel filter 
    pcl::VoxelGrid<PointT> voxel_filter;
    double resolution = 0.03;
    voxel_filter.setLeafSize(resolution, resolution, resolution);       // resolution
    PointCloud::Ptr tmp(new PointCloud);
    voxel_filter.setInputCloud(globalMap);
    voxel_filter.filter(*tmp);
    tmp->swap(*globalMap);

    cout << "After filtering, point cloud has " << globalMap->size() << " points." << endl;
    if(globalMap->size() > 100)
        pcl::io::savePCDFileBinary("./imx-aibot1-vslam-map.pcd", *globalMap);
  
    ros::shutdown();

    return 0;
}
tf2::Transform ImageGrabber::TransformFromMat (cv::Mat position_mat) 
{
    cv::Mat rotation(3, 3, CV_32F);
    cv::Mat translation(3, 1, CV_32F);

    rotation = position_mat.rowRange(0, 3).colRange(0, 3);
    translation = position_mat.rowRange(0, 3).col(3);


    tf2::Matrix3x3 tf_camera_rotation (rotation.at<float> (0, 0),
                                       rotation.at<float> (0, 1),
                                       rotation.at<float> (0, 2),
                                       rotation.at<float> (1, 0),
                                       rotation.at<float> (1, 1),
                                       rotation.at<float> (1, 2),
                                       rotation.at<float> (2, 0),
                                       rotation.at<float> (2, 1),
                                       rotation.at<float> (2, 2));

    tf2::Vector3 tf_camera_translation (translation.at<float> (0),
                                        translation.at<float> (1),
                                        translation.at<float> (2));

    //Coordinate transformation matrix from orb coordinate system to ros coordinate system
    const tf2::Matrix3x3 tf_orb_to_ros (0, 0, 1,
                                       -1, 0, 0,
                                        0, -1, 0);

    //Transform from orb coordinate system to ros coordinate system on camera coordinates
    tf_camera_rotation = tf_orb_to_ros * tf_camera_rotation;
    tf_camera_translation = tf_orb_to_ros * tf_camera_translation;

    //Inverse matrix
    tf_camera_rotation = tf_camera_rotation.transpose();
    tf_camera_translation = -(tf_camera_rotation * tf_camera_translation);

    //Transform from orb coordinate system to ros coordinate system on map coordinates
    tf_camera_rotation = tf_orb_to_ros * tf_camera_rotation;
    tf_camera_translation = tf_orb_to_ros * tf_camera_translation;

    return tf2::Transform (tf_camera_rotation, tf_camera_translation);
}
#ifdef WITH_INERTIAL
void ImageGrabber::GrabIMU(const sensor_msgs::Imu& msgIMU)
{
#if 0
    cout << "IMU timestamp " << msgIMU.header.stamp.toSec() << endl;
    cout << "IMU linear acceleration " << msgIMU.linear_acceleration.x << " "<< msgIMU.linear_acceleration.y << " "<< msgIMU.linear_acceleration.z << " "<< endl;
    cout << "IMU angular velocity " << msgIMU.angular_velocity.x << " "<< msgIMU.angular_velocity.y << " "<< msgIMU.angular_velocity.z << " "<< endl;
#endif
    imx_hc_slam::IMU::Point *pIMUPoint = new imx_hc_slam::IMU::Point(msgIMU.linear_acceleration.x, msgIMU.linear_acceleration.y, msgIMU.linear_acceleration.z,
                                                                    msgIMU.angular_velocity.x, msgIMU.angular_velocity.y, msgIMU.angular_velocity.z,
                                                                    msgIMU.header.stamp.toSec());
    unique_lock<std::mutex> locker_imu(mMutexImu);
    vImuMeas.push_back(*pIMUPoint);
    pImuMeas.push_back(pIMUPoint);
    locker_imu.unlock();
}
#endif
void ImageGrabber::GrabRGBD(const sensor_msgs::ImageConstPtr& msgRGB, const sensor_msgs::ImageConstPtr& msgD)
{
    // Copy the ros image message to cv::Mat.
    cv_bridge::CvImageConstPtr cv_ptrRGB;

#ifdef ENABLE_ODOMETRY 
    odometry_data odom_data_;
#endif

    try
    {
        cv_ptrRGB = cv_bridge::toCvShare(msgRGB);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }

    cv_bridge::CvImageConstPtr cv_ptrD;
    try
    {
        cv_ptrD = cv_bridge::toCvShare(msgD);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }
    if(imageScale != 1.f)
    {
        int width = cv_ptrRGB->image.cols * imageScale;
        int height = cv_ptrRGB->image.rows * imageScale;
        cv::resize(cv_ptrRGB->image, cv_ptrRGB->image, cv::Size(width, height));
        cv::resize(cv_ptrD->image, cv_ptrD->image, cv::Size(width, height));
    }
#ifdef WITH_INERTIAL
    Sophus::SE3f Tcw_SE3F = mpSLAM->TrackRGBD(cv_ptrRGB->image, cv_ptrD->image, cv_ptrRGB->header.stamp.toSec(), imx_hc_slam::Settings::COMPUTE_TYPE_NEON, vImuMeas);
#ifdef ENABLE_ODOMETRY    
    odom_data_.Tcw_SE3F = Tcw_SE3F;
    odom_data_.linear_velocity = mpSLAM->GetTracker()->mCurrentFrame.GetVelocity();
    if(vImuMeas.size() > 0)
        odom_data_.angular_velocity = vImuMeas[0].w;
    else
        odom_data_.angular_velocity.setZero();
#endif
    unique_lock<std::mutex> locker_imu(mMutexImu);
    for(int i = 0; i < pImuMeas.size(); ++i)
    {
        imx_hc_slam::IMU::Point *pIMUPoint = pImuMeas[i];        
        delete pIMUPoint;
    }
    vImuMeas.clear();
    pImuMeas.clear();
    locker_imu.unlock();
#else    
    Sophus::SE3f Tcw_SE3F = mpSLAM->TrackRGBD(cv_ptrRGB->image, cv_ptrD->image, cv_ptrRGB->header.stamp.toSec(), imx_hc_slam::Settings::COMPUTE_TYPE_NEON);
#ifdef ENABLE_ODOMETRY    
    odom_data_.Tcw_SE3F = Tcw_SE3F;
    odom_data_.linear_velocity.setZero();
    odom_data_.angular_velocity.setZero();
#endif
#endif

#ifdef ENABLE_IMAGE_RENDER
    std::unique_lock<std::mutex> locker_image(image_mutex_);
    image_buffer_.push(true);
    locker_image.unlock();
    image_cv_.notify_one();
#endif

#ifdef ENABLE_ODOMETRY
    std::unique_lock<std::mutex> locker_odom(odom_mutex_);
    odom_buffer_.push(odom_data_);
    locker_odom.unlock();
    odom_cv_.notify_one();
#endif
    PointCloud::Ptr keyframe_cloud = mpSLAM->GetPointCloudData();

    if (NULL != keyframe_cloud && keyframe_cloud->size() > 0)
    {
        cout << "Point cloud of key frame has " << keyframe_cloud->size() << " points." << endl;
        Eigen::Affine3f transform = Eigen::Affine3f::Identity();
        transform.rotate(Eigen::AngleAxisf(M_PI/2, Eigen::Vector3f(0,1,0)));
        pcl::transformPointCloud(*keyframe_cloud, *keyframe_cloud, transform);
        pcl::toROSMsg(*keyframe_cloud, output);
        ROS_INFO("pointclud height: %d", output.height);
        ROS_INFO("pointclud width: %d", output.width);
        output.header.stamp = cv_ptrRGB->header.stamp;
        output.header.frame_id = "map";
        pcl_pub.publish(output);

        (*globalMap) += *keyframe_cloud;  
    }
}
#ifdef ENABLE_IMAGE_RENDER
void ImageGrabber::PubImage() 
{
    sensor_msgs::Image img_msg;
    cv_bridge::CvImage img_bridge;
    cv::Mat toshow;
    std_msgs::Header header;
    bool received_image;
    header.frame_id = "camera_link";
    while (ros::ok()) {

        std::unique_lock<std::mutex> locker_image(image_mutex_);
        while (image_buffer_.empty())
            image_cv_.wait(locker_image);
        received_image = image_buffer_.front();
        image_buffer_.pop();
        locker_image.unlock();

        if(received_image) {
            toshow = mpSLAM->GetFrameDrawer()->DrawFrame(1.0f);
            header.stamp = ros::Time::now();
            img_bridge = cv_bridge::CvImage(header, "bgr8", toshow);
            img_bridge.toImageMsg(img_msg);
            frame_pub.publish(img_msg);
        }
    }
}
#endif
#ifdef ENABLE_ODOMETRY
double vo_pose_covariance[] = {1e-4, 0, 0, 0, 0, 0, 
                		       0, 1e-4, 0, 0, 0, 0,
                		       0, 0, 1e-4, 0, 0, 0,
                		       0, 0, 0, 1e-4, 0, 0,
                		       0, 0, 0, 0, 1e-4, 0,
                		       0, 0, 0, 0, 0, 1e-4};

double vo_twist_covariance[] = {1e-4, 0, 0, 0, 0, 0, 
                		        0, 1e-4, 0, 0, 0, 0,
                		        0, 0, 1e-4, 0, 0, 0,
                		        0, 0, 0, 1e-4, 0, 0,
                		        0, 0, 0, 0, 1e-4, 0,
                		        0, 0, 0, 0, 0, 1e-4};
void ImageGrabber::PubOdometry()
{
    Eigen::Matrix4f Tcw_Matrix;
    Eigen::Vector3f linear_velocity_;
    Eigen::Vector3f angular_velocity_;
    cv::Mat Tcw;
    geometry_msgs::TransformStamped odom_trans;
    nav_msgs::Odometry odom;

    tf2_ros::TransformBroadcaster odom_broadcaster;

    while (ros::ok())
    {
        std::unique_lock<std::mutex> locker_odom(odom_mutex_);
        while(odom_buffer_.empty())
            odom_cv_.wait(locker_odom);
        Tcw_Matrix = odom_buffer_.front().Tcw_SE3F.matrix();
        linear_velocity_ = odom_buffer_.front().linear_velocity;
        angular_velocity_ = odom_buffer_.front().angular_velocity;
        odom_buffer_.pop();
        locker_odom.unlock();

        cv::eigen2cv(Tcw_Matrix, Tcw);
        tf2::Transform tf_transform = TransformFromMat(Tcw);

        odom_trans.header.frame_id = "odom";
        odom_trans.child_frame_id = "base_footprint";
        odom_trans.header.stamp = ros::Time::now();
#if 0        
        /* Add 800ms delay in odometry*/
        if (800000000 + odom_trans.header.stamp.nsec >= 1000000000)
        {
            odom_trans.header.stamp.sec += 1;
            odom_trans.header.stamp.nsec = (800000000 + odom_trans.header.stamp.nsec) - 1000000000;
        }
        else
            odom_trans.header.stamp.nsec += 800000000;
        odom_trans.transform = tf2::toMsg(tf_transform);

        odom_broadcaster.sendTransform(odom_trans);
#endif
        //filling the odometry
   		odom.header.stamp = odom_trans.header.stamp;
    	odom.header.frame_id = "odom";
    	odom.child_frame_id = "base_footprint";

    	// position
        odom.pose.pose.position.x = tf_transform.getOrigin().getX();
        odom.pose.pose.position.y = tf_transform.getOrigin().getY();
        odom.pose.pose.position.z = tf_transform.getOrigin().getZ();

        odom.pose.pose.orientation.x = tf_transform.getRotation().getX();
        odom.pose.pose.orientation.y = tf_transform.getRotation().getY();
        odom.pose.pose.orientation.z = tf_transform.getRotation().getZ();
        odom.pose.pose.orientation.w = tf_transform.getRotation().getW();

        for (unsigned int i = 0; i < 36; i++)
			odom.pose.covariance[i] = vo_pose_covariance[i];

        //velocity
    	odom.twist.twist.linear.x = linear_velocity_(0);
    	odom.twist.twist.linear.y = linear_velocity_(1);
    	odom.twist.twist.linear.z = linear_velocity_(2);
    	odom.twist.twist.angular.x = angular_velocity_(0);
    	odom.twist.twist.angular.y = angular_velocity_(1);
    	odom.twist.twist.angular.z = angular_velocity_(2);

        for (unsigned int i = 0; i < 36; i++)
			odom.twist.covariance[i] = vo_twist_covariance[i];
            
        odom_pub.publish(odom);
    }
}
#endif
