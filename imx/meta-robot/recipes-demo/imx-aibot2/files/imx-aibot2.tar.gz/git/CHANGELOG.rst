^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package imx-aibot2
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.4 (2023-10-20)
------------------
* added initial code
* Contributors: Xiaodong
