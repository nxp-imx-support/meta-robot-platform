# imx_aibot2_vslam launch file for octomap_server mapping
import os
from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    path_to_vocabulary = os.path.join(
      get_package_share_directory('imx_aibot2_vslam'),
      'param',
      'orbvoc.dbow3'
    )
    path_to_settings = os.path.join(
      get_package_share_directory('imx_aibot2_vslam'),
      'param',
      'RealSense_D455.yaml'
    )
    imx_aibot2_vslam_node = Node(
            package='imx_aibot2_vslam',
            executable='imx_aibot2_vslam',
            name='imx_aibot2_vslam',
            output='screen',
            arguments=[path_to_vocabulary, path_to_settings]
        )
    octomap_server_node = Node(
            package='octomap_server',
            executable='octomap_server_node',
            name='octomap_server',
            output='screen',
            parameters=[                   
                    {'resolution': 0.05},
                    {"frame_id": "map"},
                    {"base_frame_id": "base_link"},
                    {'sensor_model.max_range': 6.0},
                    {'pointcloud_max_z': 1.0},
                    {'pointcloud_min_z': -0.08},
                    {'ground_filter.angle': 5.0},
                    {'ground_filter.distance': 0.3},
                    {'latch': True},
                    {'filter_speckles': True},
                    {'filter_ground': True},                    
            ],
            remappings=[
                    ('cloud_in', '/imx_hc_slam_cloud'),
                    ('projected_map', '/map'),
            ]
        ) 
    return LaunchDescription([
        imx_aibot2_vslam_node,
        octomap_server_node,
	])
