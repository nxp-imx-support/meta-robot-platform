/**
* This file is part of imx-hc-slam
*
* Copyright (C) 2017-2022 NXP
* Copyright (C) 2017-2021 Carlos Campos, Richard Elvira, Juan J. Gómez Rodríguez, José M.M. Montiel and Juan D. Tardós, University of Zaragoza.
* Copyright (C) 2014-2016 Raúl Mur-Artal, José M.M. Montiel and Juan D. Tardós, University of Zaragoza.
*
* imx-hc-slam is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
* License as published by the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* imx-hc-slam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even
* the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along with imx-hc-slam.
* If not, see <http://www.gnu.org/licenses/>.
*/


#include <iostream>
#include <algorithm>
#include <vector>
#include <fstream>
#include <chrono>
#include <condition_variable>
#include <queue>
#include <thread>
#include <mutex>

#include <rclcpp/rclcpp.hpp>
#include <cv_bridge/cv_bridge.h>
#include <message_filters/subscriber.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <Eigen/Core>
#include <opencv2/core/core.hpp>
#include <opencv2/core/eigen.hpp>
#include <tf2_ros/transform_broadcaster.h>
#include <tf2/LinearMath/Transform.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <nav_msgs/msg/odometry.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/pose_array.hpp>

#include <pcl/common/transforms.h>
#include <pcl/common/projection_matrix.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/voxel_grid.h>
#ifdef WITH_INERTIAL
#include <sensor_msgs/msg/imu.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <std_msgs/msg/float32.hpp>
#endif
#include <octomap/octomap.h> 
#include <opencv2/core/core.hpp>

#include <System.h>

using namespace std;
using namespace Eigen;
using std::placeholders::_1;
#ifdef ENABLE_ODOMETRY
struct odometry_data
{
    Sophus::SE3f Tcw_SE3F;
    Eigen::Vector3f linear_velocity;
    Eigen::Vector3f angular_velocity;
};
#endif
class ImageGrabber
{
public:
    ImageGrabber(imx_hc_slam::System *pSLAM):mpSLAM(pSLAM)
    {
        pNodeHandle = rclcpp::Node::make_shared("imx_aibot2_vslam");

        pNodeHandle->declare_parameter<std::string>("subscribe_image_topic",
                                              "/camera/color/image_raw");
        pNodeHandle->get_parameter("subscribe_image_topic", imx_image_topic); //Intel® RealSense™ D455's topic

        pNodeHandle->declare_parameter<std::string>("subscribe_depth_topic",
                                              "/camera/depth/image_rect_raw");
        pNodeHandle->get_parameter("subscribe_depth_topic", imx_depth_topic); //Intel® RealSense™ D455's topic
#ifdef WITH_INERTIAL
        std::string imx_imu_topic;
        pNodeHandle->declare_parameter<std::string>("subscribe_imu_topic",
                                              "/camera/imu");
        pNodeHandle->get_parameter("subscribe_imu_topic", imx_imu_topic); //Intel® RealSense™ D455's topic

        imu_sub = pNodeHandle->create_subscription<sensor_msgs::msg::Imu>(imx_imu_topic, rclcpp::QoS(rclcpp::KeepLast(150)), std::bind(&ImageGrabber::GrabIMU, this, _1));

#endif

        frame_pub = pNodeHandle->
                create_publisher<sensor_msgs::msg::Image>("keypoint_frame", 10);
    
        keyframe_pcl_pub = pNodeHandle->
                create_publisher<sensor_msgs::msg::PointCloud2>("imx_hc_slam_cloud", 10);
#ifdef ENABLE_ODOMETRY
        odom_pub = pNodeHandle->
                create_publisher<nav_msgs::msg::Odometry>("/imx_aibot2_odometer/odometry", 10);
#endif
    }

    void GrabRGBD(const sensor_msgs::msg::Image::ConstSharedPtr msgRGB, const sensor_msgs::msg::Image::ConstSharedPtr msgD);

#ifdef ENABLE_IMAGE_RENDER
    void PubImage();
#endif
#ifdef ENABLE_ODOMETRY
    void PubOdometry();
#endif
    void PubPointCloud();
#ifdef WITH_INERTIAL
    void GrabIMU(const sensor_msgs::msg::Imu& msgIMU);
    std::mutex mMutexImu;
    std::vector<imx_hc_slam::IMU::Point*> pImuMeas;
    std::vector<imx_hc_slam::IMU::Point> vImuMeas;  
    rclcpp::Subscription<sensor_msgs::msg::Imu>::SharedPtr imu_sub;
#endif

    imx_hc_slam::System* mpSLAM;
    std::string imx_image_topic;
    std::string imx_depth_topic;
#ifdef WITH_INERTIAL
    std::string imx_imu_topic;
#endif

    float imageScale;
    rclcpp::Node::SharedPtr pNodeHandle;

    rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr frame_pub; 
    rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr keyframe_pcl_pub;
#ifdef ENABLE_ODOMETRY
    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odom_pub;
#endif
private:

    tf2::Transform TransformFromMat (cv::Mat position_mat);

    std::queue<bool> image_buffer_;
    std::mutex image_mutex_;
    std::condition_variable image_cv_;

    std::queue<PointCloud::Ptr> point_buffer_;
    std::mutex point_mutex_;
    std::condition_variable point_cv_;

#ifdef ENABLE_ODOMETRY
    std::queue<odometry_data> odom_buffer_;
    std::mutex odom_mutex_;
    std::condition_variable odom_cv_;
#endif
protected:    
    sensor_msgs::msg::PointCloud2 output;
};
PointCloud::Ptr globalMap(new PointCloud);
int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);

    if(argc < 3)
    {
        std::cerr << std::endl << "Usage: ros2 run imx-aibot2_vslam imx-aibot2_vslam path_to_vocabulary path_to_settings" << std::endl;        
        rclcpp::shutdown();
        return 1;
    }

    // Create SLAM system. It initializes all system threads and gets ready to process frames.
#ifdef WITH_INERTIAL
    imx_hc_slam::System SLAM(argv[1], argv[2], imx_hc_slam::System::IMU_RGBD, false);
#else
    imx_hc_slam::System SLAM(argv[1], argv[2], imx_hc_slam::System::RGBD, false);
#endif
    ImageGrabber igb(&SLAM);

    igb.imageScale = SLAM.GetImageScale();
    
    message_filters::Subscriber<sensor_msgs::msg::Image> rgb_sub(
            igb.pNodeHandle, igb.imx_image_topic, rclcpp::SensorDataQoS().get_rmw_qos_profile());
    message_filters::Subscriber<sensor_msgs::msg::Image> depth_sub(
            igb.pNodeHandle, igb.imx_depth_topic, rclcpp::SensorDataQoS().get_rmw_qos_profile()); 

    typedef message_filters::sync_policies::ApproximateTime
    <sensor_msgs::msg::Image, sensor_msgs::msg::Image> sync_pol;
    message_filters::Synchronizer<sync_pol> sync(sync_pol(10), rgb_sub, depth_sub);
    sync.registerCallback(std::bind(&ImageGrabber::GrabRGBD,
                                    &igb,
                                    std::placeholders::_1,
                                    std::placeholders::_2));

#ifdef ENABLE_ODOMETRY
    std::thread pub_odom_thread(&ImageGrabber::PubOdometry, &igb);
#endif

#ifdef ENABLE_IMAGE_RENDER
    std::thread pub_image_thread(&ImageGrabber::PubImage, &igb);
#endif

    std::thread pub_pcl_thread(&ImageGrabber::PubPointCloud, &igb);

    rclcpp::spin(igb.pNodeHandle);

    // Stop all threads
    SLAM.Shutdown();

    globalMap->is_dense = false;
    std::cout << "point cloud has " << globalMap->size() << " points." << std::endl;

    // voxel filter 
    pcl::VoxelGrid<PointT> voxel_filter;
    double resolution = 0.03;
    voxel_filter.setLeafSize(resolution, resolution, resolution);       // resolution
    PointCloud::Ptr tmp(new PointCloud);
    voxel_filter.setInputCloud(globalMap);
    voxel_filter.filter(*tmp);
    tmp->swap(*globalMap);

    std::cout << "After filtering, point cloud has " << globalMap->size() << " points." << std::endl;
    if(globalMap->size() > 100)
        pcl::io::savePCDFileBinary("./imx-aibot2-vslam-map.pcd", *globalMap);
  
    rclcpp::shutdown();

    return 0;
}
tf2::Transform ImageGrabber::TransformFromMat (cv::Mat position_mat) 
{
    cv::Mat rotation(3, 3, CV_32F);
    cv::Mat translation(3, 1, CV_32F);

    rotation = position_mat.rowRange(0, 3).colRange(0, 3);
    translation = position_mat.rowRange(0, 3).col(3);


    tf2::Matrix3x3 tf_camera_rotation (rotation.at<float> (0, 0),
                                       rotation.at<float> (0, 1),
                                       rotation.at<float> (0, 2),
                                       rotation.at<float> (1, 0),
                                       rotation.at<float> (1, 1),
                                       rotation.at<float> (1, 2),
                                       rotation.at<float> (2, 0),
                                       rotation.at<float> (2, 1),
                                       rotation.at<float> (2, 2));

    tf2::Vector3 tf_camera_translation (translation.at<float> (0),
                                        translation.at<float> (1),
                                        translation.at<float> (2));

    //Coordinate transformation matrix from orb coordinate system to ros coordinate system
    const tf2::Matrix3x3 tf_orb_to_ros (0, 0, 1,
                                       -1, 0, 0,
                                        0, -1, 0);

    //Transform from orb coordinate system to ros coordinate system on camera coordinates
    tf_camera_rotation = tf_orb_to_ros * tf_camera_rotation;
    tf_camera_translation = tf_orb_to_ros * tf_camera_translation;

    //Inverse matrix
    tf_camera_rotation = tf_camera_rotation.transpose();
    tf_camera_translation = -(tf_camera_rotation * tf_camera_translation);

    //Transform from orb coordinate system to ros coordinate system on map coordinates
    tf_camera_rotation = tf_orb_to_ros * tf_camera_rotation;
    tf_camera_translation = tf_orb_to_ros * tf_camera_translation;

    return tf2::Transform (tf_camera_rotation, tf_camera_translation);
}
#ifdef WITH_INERTIAL
void ImageGrabber::GrabIMU(const sensor_msgs::msg::Imu& msgIMU)
{
#if 0
    cout << "IMU timestamp " << rclcpp::Time(msgIMU.header.stamp).seconds() << endl;
    cout << "IMU linear acceleration " << msgIMU.linear_acceleration.x << " "<< msgIMU.linear_acceleration.y << " "<< msgIMU.linear_acceleration.z << " "<< endl;
    cout << "IMU angular velocity " << msgIMU.angular_velocity.x << " "<< msgIMU.angular_velocity.y << " "<< msgIMU.angular_velocity.z << " "<< endl;
#endif
    imx_hc_slam::IMU::Point *pIMUPoint = new imx_hc_slam::IMU::Point(msgIMU.linear_acceleration.x, msgIMU.linear_acceleration.y, msgIMU.linear_acceleration.z,
                                                                    msgIMU.angular_velocity.x, msgIMU.angular_velocity.y, msgIMU.angular_velocity.z,
                                                                    rclcpp::Time(msgIMU.header.stamp).seconds());
    unique_lock<std::mutex> locker_imu(mMutexImu);
    vImuMeas.push_back(*pIMUPoint);
    pImuMeas.push_back(pIMUPoint);
    locker_imu.unlock();
}
#endif

void ImageGrabber::GrabRGBD(const sensor_msgs::msg::Image::ConstSharedPtr msgRGB, const sensor_msgs::msg::Image::ConstSharedPtr msgD)
{
    // Copy the ros image message to cv::Mat.
    cv_bridge::CvImageConstPtr cv_ptrRGB;

#ifdef ENABLE_ODOMETRY 
    odometry_data odom_data_;
#endif

    try
    {
        cv_ptrRGB = cv_bridge::toCvShare(msgRGB);
    }
    catch (cv_bridge::Exception& e)
    {
        RCLCPP_ERROR(pNodeHandle->get_logger(), "cv_bridge exception: %s", e.what());
        return;
    }

    cv_bridge::CvImageConstPtr cv_ptrD;
    try
    {
        cv_ptrD = cv_bridge::toCvShare(msgD);
    }
    catch (cv_bridge::Exception& e)
    {
        RCLCPP_ERROR(pNodeHandle->get_logger(), "cv_bridge exception: %s", e.what());
        return;
    }
    if(imageScale != 1.f)
    {
        int width = cv_ptrRGB->image.cols * imageScale;
        int height = cv_ptrRGB->image.rows * imageScale;
        cv::resize(cv_ptrRGB->image, cv_ptrRGB->image, cv::Size(width, height));
        cv::resize(cv_ptrD->image, cv_ptrD->image, cv::Size(width, height));
    }
#ifdef WITH_INERTIAL
    Sophus::SE3f Tcw_SE3F = mpSLAM->TrackRGBD(cv_ptrRGB->image, cv_ptrD->image, rclcpp::Time(cv_ptrRGB->header.stamp).seconds(), imx_hc_slam::Settings::COMPUTE_TYPE_NEON, vImuMeas);    
#ifdef ENABLE_ODOMETRY    
    odom_data_.Tcw_SE3F = Tcw_SE3F;
    odom_data_.linear_velocity = mpSLAM->GetTracker()->mCurrentFrame.GetVelocity();
    if(vImuMeas.size() > 0)
        odom_data_.angular_velocity = vImuMeas[0].w;
    else
        odom_data_.angular_velocity.setZero();
#endif
    unique_lock<std::mutex> locker_imu(mMutexImu);
    for(int i = 0; i < pImuMeas.size(); ++i)
    {
        imx_hc_slam::IMU::Point *pIMUPoint = pImuMeas[i];        
        delete pIMUPoint;
    }
    vImuMeas.clear();
    pImuMeas.clear();
    locker_imu.unlock();
#else    
    Sophus::SE3f Tcw_SE3F = mpSLAM->TrackRGBD(cv_ptrRGB->image, cv_ptrD->image, rclcpp::Time(cv_ptrRGB->header.stamp).seconds(), imx_hc_slam::Settings::COMPUTE_TYPE_NEON);
#ifdef ENABLE_ODOMETRY    
    odom_data_.Tcw_SE3F = Tcw_SE3F;
    odom_data_.linear_velocity.setZero();
    odom_data_.angular_velocity.setZero();
#endif
#endif

#ifdef ENABLE_IMAGE_RENDER
    std::unique_lock<std::mutex> locker_image(image_mutex_);
    image_buffer_.push(true);
    locker_image.unlock();
    image_cv_.notify_one();
#endif

#ifdef ENABLE_ODOMETRY
    std::unique_lock<std::mutex> locker_odom(odom_mutex_);
    odom_buffer_.push(odom_data_);
    locker_odom.unlock();
    odom_cv_.notify_one();
#endif
    PointCloud::Ptr keyframe_cloud = mpSLAM->GetPointCloudData();

    if (NULL != keyframe_cloud && keyframe_cloud->size() > 0)
    {
        RCLCPP_INFO(pNodeHandle->get_logger(), "Point cloud of key frame has: %d points.", keyframe_cloud->size());
        std::unique_lock<std::mutex> locker_point(point_mutex_);
        point_buffer_.push(keyframe_cloud);
        locker_point.unlock();
        point_cv_.notify_one();
    }
}
#ifdef ENABLE_IMAGE_RENDER
void ImageGrabber::PubImage() 
{
    sensor_msgs::msg::Image img_msg;
    cv_bridge::CvImage img_bridge;
    cv::Mat toshow;
    std_msgs::msg::Header header;
    bool received_image;
    header.frame_id = "camera_link";
    while (rclcpp::ok())
    {

        std::unique_lock<std::mutex> locker_image(image_mutex_);
        while (image_buffer_.empty())
            image_cv_.wait(locker_image);
        received_image = image_buffer_.front();
        image_buffer_.pop();
        locker_image.unlock();

        if(received_image)
        {
            toshow = mpSLAM->GetFrameDrawer()->DrawFrame(1.0f);
            header.stamp = pNodeHandle->get_clock()->now();
            img_bridge = cv_bridge::CvImage(header, "bgr8", toshow);
            img_bridge.toImageMsg(img_msg);
            frame_pub->publish(img_msg);
        }
    }
}
#endif
void ImageGrabber::PubPointCloud() 
{
    PointCloud::Ptr keyframe_cloud = static_cast<PointCloud::Ptr>(NULL);
    while (rclcpp::ok()) 
    {
        std::unique_lock<std::mutex> locker_point(point_mutex_);
        while (point_buffer_.empty())
            point_cv_.wait(locker_point);
        keyframe_cloud = point_buffer_.front();
        point_buffer_.pop();
        locker_point.unlock();
        if(static_cast<PointCloud::Ptr>(NULL) != keyframe_cloud)
        {
            Eigen::Affine3f transform = Eigen::Affine3f::Identity();
            transform.rotate(Eigen::AngleAxisf(M_PI/2, Eigen::Vector3f(0,1,0)));
            pcl::transformPointCloud(*keyframe_cloud, *keyframe_cloud, transform);
            pcl::toROSMsg(*keyframe_cloud, output);
            RCLCPP_INFO(pNodeHandle->get_logger(), "pointclud height: %d", output.height);
            RCLCPP_INFO(pNodeHandle->get_logger(), "pointclud width: %d", output.width);
            output.header.stamp = pNodeHandle->get_clock()->now();
            output.header.frame_id = "map";
            keyframe_pcl_pub->publish(output);

            (*globalMap) += *keyframe_cloud;
        }
    }
}
#ifdef ENABLE_ODOMETRY
const double vo_pose_covariance[] = {1e-4, 0, 0, 0, 0, 0, 
                		       0, 1e-4, 0, 0, 0, 0,
                		       0, 0, 1e-4, 0, 0, 0,
                		       0, 0, 0, 1e-4, 0, 0,
                		       0, 0, 0, 0, 1e-4, 0,
                		       0, 0, 0, 0, 0, 1e-4};

const double vo_twist_covariance[] = {1e-4, 0, 0, 0, 0, 0, 
                		        0, 1e-4, 0, 0, 0, 0,
                		        0, 0, 1e-4, 0, 0, 0,
                		        0, 0, 0, 1e-4, 0, 0,
                		        0, 0, 0, 0, 1e-4, 0,
                		        0, 0, 0, 0, 0, 1e-4};
void ImageGrabber::PubOdometry()
{
    Eigen::Matrix4f Tcw_Matrix;
    Eigen::Vector3f linear_velocity_;
    Eigen::Vector3f angular_velocity_;
    cv::Mat Tcw;

    nav_msgs::msg::Odometry odom;

    while (rclcpp::ok())
    {
        std::unique_lock<std::mutex> locker_odom(odom_mutex_);
        while(odom_buffer_.empty())
            odom_cv_.wait(locker_odom);
        Tcw_Matrix = odom_buffer_.front().Tcw_SE3F.matrix();
        linear_velocity_ = odom_buffer_.front().linear_velocity;
        angular_velocity_ = odom_buffer_.front().angular_velocity;
        odom_buffer_.pop();
        locker_odom.unlock();

        cv::eigen2cv(Tcw_Matrix, Tcw);
        tf2::Transform tf_transform = TransformFromMat(Tcw);

        //filling the odometry
   		odom.header.stamp = pNodeHandle->get_clock()->now();
    	odom.header.frame_id = "odom";
    	odom.child_frame_id = "base_footprint";

    	// position
        odom.pose.pose.position.x = tf_transform.getOrigin().getX();
        odom.pose.pose.position.y = tf_transform.getOrigin().getY();
        odom.pose.pose.position.z = tf_transform.getOrigin().getZ();

        odom.pose.pose.orientation.x = tf_transform.getRotation().getX();
        odom.pose.pose.orientation.y = tf_transform.getRotation().getY();
        odom.pose.pose.orientation.z = tf_transform.getRotation().getZ();
        odom.pose.pose.orientation.w = tf_transform.getRotation().getW();

        for (unsigned int i = 0; i < 36; i++)
			odom.pose.covariance[i] = vo_pose_covariance[i];

        //velocity
    	odom.twist.twist.linear.x = linear_velocity_(0);
    	odom.twist.twist.linear.y = linear_velocity_(1);
    	odom.twist.twist.linear.z = linear_velocity_(2);
    	odom.twist.twist.angular.x = angular_velocity_(0);
    	odom.twist.twist.angular.y = angular_velocity_(1);
    	odom.twist.twist.angular.z = angular_velocity_(2);

        for (unsigned int i = 0; i < 36; i++)
			odom.twist.covariance[i] = vo_twist_covariance[i];
            
        odom_pub->publish(odom);
    }
}
#endif
