/*
 * Copyright 2017-2023 NXP
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright notice,
 *      this list of conditions and the following disclaimer in the documentation
 *      and/or other materials provided with the distribution.
 *
 *    * Neither the name of the NXP. nor the names of
 *      its contributors may be used to endorse or promote products derived from
 *      this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
#include <string>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <tf2_ros/transform_broadcaster.h>
#include <tf2/LinearMath/Quaternion.h>
#include <nav_msgs/msg/odometry.hpp>
#include <std_msgs/msg/string.hpp>
#include <iostream>
#include <cmath>

#include "comm.h"

using namespace std;

// initial position
double x = 0.0;
double y = 0.0;
double th = 0;

// RMCALL global
char const *param_ttyPath = NULL;
rmcall_t rmcall_mcu;
rmcall_teleport_t uart_teleport_mcu =
{
    RMCALL_HOST_Tx,
    RMCALL_HOST_Rx,
    RMCALL_HOST_TxAbort,
    RMCALL_HOST_RxAbort,
};
rmcall_config_t rmcall_mcuConfig =
{
    .teleport = &uart_teleport_mcu,
};

// Control packet global
comm_packet_control_t comm_control = {0, 0, 0, 0, 0,};

double speed_scale = 1.0;
double speed_dead_zone = 0.005;
double speed_limit_min = 0.015;
double speed_limit_max = 0.1;
double steer_wheel_base = 0.2;
double steer_scale = 1.0;
double steer_limit = 150.0;
rclcpp::Node::SharedPtr pNodeHandle;

double wheel_odom_pose_covariance[] = {1e-3, 0, 0, 0, 0, 0, 
                		               0, 1e-3, 0, 0, 0, 0,
                		               0, 0, 1e-3, 0, 0, 0,
                		               0, 0, 0, 1e-3, 0, 0,
                		               0, 0, 0, 0, 1e-3, 0,
                		               0, 0, 0, 0, 0, 1e-3};

double wheel_odom_twist_covariance[] = {1e-3, 0, 0, 0, 0, 0, 
                		                0, 1e-3, 0, 0, 0, 0,
                		                0, 0, 1e-3, 0, 0, 0,
                		                0, 0, 0, 1e-3, 0, 0,
                		                0, 0, 0, 0, 1e-3, 0,
                		                0, 0, 0, 0, 0, 1e-3};

void cmd_velCallback(const geometry_msgs::msg::Twist::SharedPtr twist_aux)
{
    /** shadow values used to log previous command */
    static int16_t motor_speed_shadow = 0, servo_steer_shadow = 0;
    bool steer_error = false;

    /** calculate speed */
    double speed = twist_aux->linear.x * speed_scale;
    double speed_limited;
    /**
    * For speed >= 0:
    * - If speed <= speed_dead_zone, the car will stop;
    * - If speed > speed_dead_zone && speed < speed_limit_min, the car
    *   will move at speed_limit_min;
    * - If speed > speed_limit_max,  the car will move at speed_limit_max;
    * - Otherwise, car will move at speed.
    */
    if (speed >= 0.0)
        speed_limited = speed > speed_dead_zone ?
                    (speed > speed_limit_min ?
                    	(speed > speed_limit_max ? speed_limit_max : speed)
                        : speed_limit_min)
                    : 0.0;
    else
    speed_limited = speed < -speed_dead_zone ?
        			(speed < -speed_limit_min ?
        				(speed < -speed_limit_max ? -speed_limit_max : speed)
        			: -speed_limit_min)
            		: 0.0;

    /** calculate steer */
    double steer = 0.0;
    double steer_limited = 0.0;
    steer_error = false;
    if( abs(twist_aux->angular.z) > 0.0001 ) // commanded to turn
    {
        if( abs(speed_limited) < speed_dead_zone ) // not able to move, move at lowest speed and turn at max rate
        {
            speed_limited = speed_limit_min; // override and run in minimal speed.
            steer_error = true;	// mark that speed error is caused by steer override.
        }
        steer = twist_aux->angular.z * steer_scale * steer_wheel_base / speed_limited;
        steer_limited = steer > steer_limit ? steer_limit : steer;
        steer_limited = steer < -steer_limit ? -steer_limit : steer;
    }
    else // commanded to go straight
    {
        steer_limited = 0.0;
    }

    /** prepare command packet */
    comm_control.motor_speed = speed_limited * 1000.0; // m/s to mm/s
    comm_control.servo_steer = 1500 + steer_limited;
    comm_control.controlFlag = 0U;

    /** discard this packet if no changes are made */
    if( motor_speed_shadow == comm_control.motor_speed && 0.0 != comm_control.motor_speed &&
    servo_steer_shadow == comm_control.servo_steer )
    {
        //ROS_INFO("Command not changed\n");
        return;
    }

    /** actually send the command */
    RMCALL_CommandSend(&rmcall_mcu, 0x0101, (void*)&comm_control, sizeof(comm_packet_control_t));

    /** update shadow values */
    motor_speed_shadow = comm_control.motor_speed;
    servo_steer_shadow = comm_control.servo_steer;

    /** check and print errors */
    if(abs(speed) < speed_dead_zone)
        RCLCPP_WARN(pNodeHandle->get_logger(), "base_control speed in deadzone %lf, %lf, %lf", twist_aux->linear.x, speed, speed_limited);
    else if( abs(speed - speed_limited) > 0.0001 )
        RCLCPP_WARN(pNodeHandle->get_logger(), "base_control invalid speed: %lf, %lf, %lf", twist_aux->linear.x, speed, speed_limited);
    if( abs(steer - steer_limited) > 0.0001 || steer_error )
        RCLCPP_WARN(pNodeHandle->get_logger(), "base_control invalid steer: %lf, %lf, %lf", twist_aux->angular.z, steer, steer_limited);

    /** print debug message */
#if 0
    RCLCPP_INFO(pNodeHandle->get_logger(), "Twist linear: x = %lf, y = %lf, w = %lf", twist_aux->linear.x, twist_aux->linear.y, twist_aux->angular.z);
    RCLCPP_INFO(pNodeHandle->get_logger(), "Twist angular: x = %lf, y = %lf, w = %lf", twist_aux->angular.x, twist_aux->angular.y, twist_aux->angular.z);
    RCLCPP_INFO(pNodeHandle->get_logger(), "Command Info:\nSpeed: %hd  Steer: %hd\nPan: %hd  Tlt: %hd\nFlag: %d\n",
    	comm_control.motor_speed, comm_control.servo_steer, comm_control.cam_pan, comm_control.cam_tlt,
    	comm_control.controlFlag);
#endif
}

/** Odometry data & lock
** extern defined in "comm_host.c" */
extern pthread_mutex_t odom_mutex;
extern pthread_cond_t odom_cond;
extern comm_packet_odometry_t odom_data;
extern volatile bool odom_ready;

int main(int argc, char** argv)
{
    std::string devicePathStr;
    rclcpp::init(argc, argv);
    pNodeHandle = rclcpp::Node::make_shared("imx_aibot2_node");

    pNodeHandle->declare_parameter<std::string>("uart_port.device_path", "/dev/ttymxc1");
    pNodeHandle->declare_parameter<double>("drive_controller.speed_scale", 1.0);
    pNodeHandle->declare_parameter<double>("drive_controller.speed_dead_zone", 0.005);
    pNodeHandle->declare_parameter<double>("drive_controller.speed_limit_min", 0.015);
    pNodeHandle->declare_parameter<double>("drive_controller.speed_limit_max", 0.1);
    pNodeHandle->declare_parameter<double>("drive_controller.steer_wheel_base", 0.2);
    pNodeHandle->declare_parameter<double>("drive_controller.steer_scale", 1.0);
    pNodeHandle->declare_parameter<double>("drive_controller.steer_limit", 150.0);
    
    // velocity
    double vx = 0.0;
    double vth = 0.0;

    // FIXME: I have removed "ros::Rate loop_rate()"
    // You may want to remove these as well, timer is no longer needed.
    rclcpp::Time current_time;
    rclcpp::Time last_time;
    current_time = pNodeHandle->get_clock()->now();
    last_time = pNodeHandle->get_clock()->now();

    tf2_ros::TransformBroadcaster odom_broadcaster(pNodeHandle);

    pNodeHandle->get_parameter_or<std::string>("uart_port.device_path", devicePathStr, std::string("/dev/ttymxc1"));
    RCLCPP_INFO(pNodeHandle->get_logger(), "Open port: '%s'", devicePathStr.c_str());

    /** Get params from ROS */
    pNodeHandle->get_parameter_or<double>("drive_controller.speed_scale", speed_scale, 1.0);				// Coefficient converting speed to m/s
    pNodeHandle->get_parameter_or<double>("drive_controller.speed_dead_zone", speed_dead_zone, 0.005);	// Deadzone of speed input value.
    pNodeHandle->get_parameter_or<double>("drive_controller.speed_limit_min", speed_limit_min, 0.015);	// Minimium speed if speed inout exceeds deadzone
    pNodeHandle->get_parameter_or<double>("drive_controller.speed_limit_max", speed_limit_max, 0.1);		// Maximium speed.
    pNodeHandle->get_parameter_or<double>("drive_controller.steer_wheel_base", steer_wheel_base, 0.2);	// wheel base in meter, default to 20cm.
    pNodeHandle->get_parameter_or<double>("drive_controller.steer_scale", steer_scale, 1.0);			// Coefficient converting steer to output, default to 150 / (PI/6), so 30 DEG is the full damping.
    pNodeHandle->get_parameter_or<double>("drive_controller.steer_limit", steer_limit, 150.0);			// Full scale output, default to 1500 ± 150.

    /** Print params for debug */
    RCLCPP_INFO(pNodeHandle->get_logger(), "param speed_scale = %lf\n", speed_scale);
    RCLCPP_INFO(pNodeHandle->get_logger(), "param speed_dead_zone = %lf\n", speed_dead_zone);
    RCLCPP_INFO(pNodeHandle->get_logger(), "param speed_limit_min = %lf\n", speed_limit_min);
    RCLCPP_INFO(pNodeHandle->get_logger(), "param speed_limit_max = %lf\n", speed_limit_max);
    RCLCPP_INFO(pNodeHandle->get_logger(), "param steer_wheel_base = %lf\n", steer_wheel_base);
    RCLCPP_INFO(pNodeHandle->get_logger(), "param steer_scale = %lf\n", steer_scale);
    RCLCPP_INFO(pNodeHandle->get_logger(), "param steer_limit = %lf\n", steer_limit);

    /** open uart, init rmcall and enable rx */
    param_ttyPath = devicePathStr.c_str();
    RMCALL_Init(&rmcall_mcu, &rmcall_mcuConfig);
    extern rmcall_handle_t comm_packetReceive_telemetry;
    RMCALL_HandleInsert(&rmcall_mcu, &comm_packetReceive_telemetry);
    while(mStatus_Success != RMCALL_CommandRecvEnable(&rmcall_mcu))
    {
        // do nothing
    }

    /** send reset packet and enable odometry report */
    comm_control.motor_speed = 0;
    comm_control.servo_steer = 1500;
    comm_control.cam_pan = 1500;
    comm_control.cam_tlt = 1500;
    comm_control.controlFlag = comm_controlFlag_odomEnable;
    RMCALL_CommandSend(&rmcall_mcu, 0x0101, (void*)&comm_control, sizeof(comm_packet_control_t));

    /** print debug message. */
    RCLCPP_INFO(pNodeHandle->get_logger(), "Enable odometry auto-reporting.\n");
#if 0	
    RCLCPP_INFO(pNodeHandle->get_logger(), "Command Info:\nSpeed: %hd  Steer: %hd\nPan: %hd  Tlt: %hd\nFlag: %d\n",
    	comm_control.motor_speed, comm_control.servo_steer, comm_control.cam_pan, comm_control.cam_tlt,
    	comm_control.controlFlag);
#endif
    /** init lock, subscribe geometry_msgs and insert rmcall receive handle */
    pthread_mutex_init(&odom_mutex, NULL);
    pthread_cond_init(&odom_cond, NULL);


    rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_sub = pNodeHandle->create_subscription<geometry_msgs::msg::Twist>("cmd_vel", 10, &cmd_velCallback);

#ifdef REPORT_WHEEL_ODOMETRY
    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odom_pub = pNodeHandle->create_publisher<nav_msgs::msg::Odometry>("wheel_odom", 10);
#else
    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odom_pub = pNodeHandle->create_publisher<nav_msgs::msg::Odometry>("odom", 10);
#endif
#if defined(CONFIG_ODOMETRY_REPORT) && (CONFIG_ODOMETRY_REPORT != 0U)
    extern rmcall_handle_t comm_packetReceive_odometry;
    RMCALL_HandleInsert(&rmcall_mcu, &comm_packetReceive_odometry);
#endif // ! CONFIG_ODOMETRY_REPORT

#ifdef REPORT_WHEEL_ODOMETRY
    nav_msgs::msg::Odometry odom;
    odom.header.frame_id = "odom";
    odom.child_frame_id = "base_footprint";
#else
    geometry_msgs::msg::TransformStamped odom_trans;
    odom_trans.header.frame_id = "odom";
    odom_trans.child_frame_id = "base_footprint";
    nav_msgs::msg::Odometry odom;
    odom.header.frame_id = "odom";
    odom.child_frame_id = "base_footprint";
#endif
    while(rclcpp::ok())
    {
        /** cond wait for new data is ready */
        pthread_mutex_lock(&odom_mutex);
        while(false == odom_ready)
        {
            pthread_cond_wait(&odom_cond, &odom_mutex);
        }

        current_time = pNodeHandle->get_clock()->now();
        RCLCPP_DEBUG(pNodeHandle->get_logger(), "Get odometry and publish it.");

        /** access "odom_data" and send ros msg */
        vx = odom_data.velocity;
        vth = odom_data.rotation;

        odom_ready = false;
        pthread_mutex_unlock(&odom_mutex);

        { /** calculate odom base on vx and vth */
            double dt = 0.05; // we use 50 ms interval on RT1064. //(current_time - last_time).toSec();
            double delta_x = vx * cos(th) * dt;
            double delta_y = vx * sin(th) * dt;
            double delta_th = vth * dt;

            x += delta_x;
            y += delta_y;
            th += delta_th;
            tf2::Quaternion q;
            q.setRPY(0.0, 0.0,th);
#ifdef REPORT_WHEEL_ODOMETRY

            /** filling the odometry */
            odom.header.stamp = current_time;

            // position
            odom.pose.pose.position.x = x;
            odom.pose.pose.position.y = y;
            odom.pose.pose.position.z = 0.0;
            odom.pose.pose.orientation.x = q.x();
            odom.pose.pose.orientation.y = q.y();
            odom.pose.pose.orientation.z = q.z();
            odom.pose.pose.orientation.w = q.w();
            for (unsigned int i = 0; i < 36; i++)
            	odom.pose.covariance[i] = wheel_odom_pose_covariance[i];

            //velocity
            odom.twist.twist.linear.x = vx;
            odom.twist.twist.linear.y = 0.0;
            odom.twist.twist.linear.z = 0.0;
            odom.twist.twist.angular.x = 0.0;
            odom.twist.twist.angular.y = 0.0;
            odom.twist.twist.angular.z = vth;
            for (unsigned int i = 0; i < 36; i++)
            	odom.twist.covariance[i] = wheel_odom_twist_covariance[i];

            /** publishing the odometry */
            odom_pub->publish(odom);
#else
            /** update transform */
            odom_trans.header.stamp = current_time;
            odom_trans.transform.translation.x = x;
            odom_trans.transform.translation.y = y;
            odom_trans.transform.translation.z = 0.0;
            odom_trans.transform.rotation.x = q.x();
            odom_trans.transform.rotation.y = q.y();
            odom_trans.transform.rotation.z = q.z();
            odom_trans.transform.rotation.w = q.w();

            /* Add 20ms delay in odometry*/
#define DELAY_TIME  20000000
            double time_s = current_time.seconds();
            double time_ns = current_time.nanoseconds();
            if (DELAY_TIME + time_ns >= 1000000000)
            {
                time_s += 1;
                time_ns = (DELAY_TIME + time_ns) - 1000000000;
            }
            else
                time_ns += DELAY_TIME;

            odom_trans.header.stamp = rclcpp::Time(time_s, time_ns);
            /** filling the odometry */
            odom.header.stamp = odom_trans.header.stamp;

            // position
            odom.pose.pose.position.x = x;
            odom.pose.pose.position.y = y;
            odom.pose.pose.position.z = 0.0;
            odom.pose.pose.orientation.x = q.x();
            odom.pose.pose.orientation.y = q.y();
            odom.pose.pose.orientation.z = q.z();
            odom.pose.pose.orientation.w = q.w();

            //velocity
            odom.twist.twist.linear.x = vx;
            odom.twist.twist.linear.y = 0.0;
            odom.twist.twist.linear.z = 0.0;
            odom.twist.twist.angular.x = 0.0;
            odom.twist.twist.angular.y = 0.0;
            odom.twist.twist.angular.z = vth;

            /** publishing the odometry and the new tf */
            odom_broadcaster.sendTransform(odom_trans);
            odom_pub->publish(odom);
#endif
        }

        last_time = current_time;
        rclcpp::spin_some(pNodeHandle);
    }
}
