from setuptools import find_packages
from setuptools import setup

package_name = 'imx_aibot2_teleop'

setup(
    name=package_name,
    version='2.0.0',
    packages=find_packages(exclude=[]),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Xiaodong Zhang',
    maintainer_email='xiaodong.zhang@nxp.com',
    keywords=['ROS'],
    description=(
        'Provides teleoperation using keyboard and joystick for i.MX AIBot.'
    ),
    license='BSD',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'imx_aibot2_teleoperator = imx_aibot2_teleop.script.imx_aibot2_teleoperator:main'
        ],
    },
)
