# imx-aibot2_description launch file
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    urdf = os.path.join(
        get_package_share_directory('imx_aibot2_description'),
        'urdf',
        'imxaibot.urdf')

    # Major refactor of the robot_state_publisher
    # Reference page: https://github.com/ros2/demos/pull/426
    with open(urdf, 'r') as infp:
        robot_desc = infp.read()

    # print (robot_desc) # Printing urdf information.

    return LaunchDescription([
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': robot_desc}, {'publish_frequency': 50.0}]),
    ])
